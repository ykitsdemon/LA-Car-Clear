if Config.UseESX then
    ESX = exports["es_extended"]:getSharedObject()
elseif Config.UseQBCore then
    -- QBCore related code
    QBCore = exports['qb-core']:GetCoreObject()
end


RegisterNetEvent("delall")
AddEventHandler("delall", function ()
    if Config.alerts then
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 2 Minutes' })
        Citizen.Wait(60000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 1 Minutes' })
        Citizen.Wait(15000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 30 seconds' })
        Citizen.Wait(15000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 15 seconds' })
        Citizen.Wait(5000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 10 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 9 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 8 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 7 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 6 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 5 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 4 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 3 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 2 seconds' })
        Citizen.Wait(1000)
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'Incoming City Tow In 1 Second' })
    end
    Citizen.Wait(1000) 
    for vehicle in EnumerateVehicles() do            
        if (not IsPedAPlayer(GetPedInVehicleSeat(vehicle, -1))) then 
            if Config.OnlyWipeBroken == true then
                if GetVehicleEngineHealth(vehicle) <= 100.0 then
                    SetVehicleHasBeenOwnedByPlayer(vehicle, false) 
                    SetEntityAsMissionEntity(vehicle, false, false) 
                    DeleteVehicle(vehicle)
                    if Config.UseESX then
                        ESX.Game.DeleteVehicle(vehicle)
                    end
                    DeleteEntity(vehicle)
                    DeleteVehicle(vehicle) 
                    if Config.UseESX then
                        ESX.Game.DeleteVehicle(vehicle)
                    end
                    DeleteEntity(vehicle)
                    if (DoesEntityExist(vehicle)) then 
                        DeleteVehicle(vehicle) 
                        if Config.UseESX then
                            ESX.Game.DeleteVehicle(vehicle)
                        end
                        DeleteEntity(vehicle)
                        DeleteVehicle(vehicle)
                        if Config.UseESX then 
                            ESX.Game.DeleteVehicle(vehicle)
                        end
                        DeleteEntity(vehicle)
                    end
                end
            else
                SetVehicleHasBeenOwnedByPlayer(vehicle, false) 
                SetEntityAsMissionEntity(vehicle, false, false) 
                DeleteVehicle(vehicle)
                if Config.UseESX then
                    ESX.Game.DeleteVehicle(vehicle)
                end
                DeleteEntity(vehicle)
                DeleteVehicle(vehicle) 
                if Config.UseESX then
                    ESX.Game.DeleteVehicle(vehicle)
                end
                DeleteEntity(vehicle)
                if (DoesEntityExist(vehicle)) then 
                    DeleteVehicle(vehicle) 
                    if Config.UseESX then
                        ESX.Game.DeleteVehicle(vehicle)
                    end
                    DeleteEntity(vehicle)
                    DeleteVehicle(vehicle)
                    if Config.UseESX then 
                        ESX.Game.DeleteVehicle(vehicle)
                    end
                    DeleteEntity(vehicle)
                end
            end
            if Config.use10msdelay then
                Citizen.Wait(10)
            end
        end
    end
    if Config.DoneNotify then
        TriggerEvent('ox_lib:notify', { type = 'inform', title = 'Los Angeles, California', position = 'center-right', icon = 'building', iconColor = '#6495ED', description = 'City Tow Completed' })
    end
end)
