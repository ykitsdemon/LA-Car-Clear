Config = {
    commandName = "citytow", -- For manual car wipes
    restricCommand = true, -- Now you need permission to do
    alerts = true, -- Notify in chat when a car wipe is coming
    use10msdelay = true, -- use 10ms delay by deleting a vehicle
    DoneNotify = true, -- Send a notify when the car wipe is done
    UseESX = true, -- Set this to true to enable ESX, false to disable
    UseQBCore = false, -- Set this to true to enable QBCore, false to disable
    OnlyWipeBroken = false, -- Only delete broken cars in the map
}
